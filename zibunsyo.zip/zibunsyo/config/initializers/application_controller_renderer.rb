# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '6ffb9676708425072c01358dff101d61bd5f67c5efe5724ae3b67ef553a04a816744cb1a8f4278c182581d981d52ac9238026980edac64361487450247563c7e'