class Genre < ApplicationRecord
  belongs_to :user
end
