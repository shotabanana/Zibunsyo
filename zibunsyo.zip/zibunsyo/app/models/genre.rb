class Genre < ApplicationRecord
  scope :latest, -> { order(created_at: :desc)}
  scope :old, -> { order(created_at: :asc)}
  scope :title, -> { order(title: :asc)}
  has_many :articles, dependent: :destroy
  belongs_to :user
end
