class Article < ApplicationRecord
  belongs_to :genre
end
