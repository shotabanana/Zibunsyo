class Article < ApplicationRecord
  scope :latest, -> { order(created_at: :desc)}
  scope :old, -> { order(created_at: :asc)}
  scope :title, -> { order(title: :asc)}
  belongs_to :genre
end
