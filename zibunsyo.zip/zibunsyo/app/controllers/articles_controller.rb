class ArticlesController < ApplicationController

  def create
    genre = Genre.find(params[:genre_id])
    article = Article.new(article_params)
    article.user_id = current_user.id
    article.genre_id = genre.id
    article.save
    redirect_to genre_path(genre.id)
  end

  def show
    @genre = Genre.find(params[:genre_id])
    @article = Article.find(params[:id])
  end

  def edit
    @genre = Genre.find(params[:genre_id])
    @article = Article.find(params[:id])
  end

  def update
    @genre = Genre.find(params[:genre_id])
    @article = Article.find(params[:id])
    if @article.update(article_params)
      flash[:notice] = 'You have updated article successfully.'
      redirect_to genre_article_path(@genre.id, @article.id)
    else
      render :edit
    end
  end

  def destroy
    @genre = Genre.find(params[:genre_id])
    @article = Article.find(params[:id])
    @article.destroy
    redirect_to genre_path(@genre.id)
  end

  private

  def article_params
    params.require(:article).permit(:title, :body)
  end

end
