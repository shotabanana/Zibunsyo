class GenresController < ApplicationController

  def create
    @genre = Genre.new(genre_params)
    @genre.user_id = current_user.id
    @genre.save
    redirect_to genre_path(@genre.id)
  end

  def show
    @genre = Genre.find(params[:id])
    @articles = Article.all
    @article_new = Article.new
  end

  def edit
    @genre = Genre.find(params[:id])
  end

  def update
    @genre = Genre.find(params[:id])
    if @genre.update(genre_params)
      flash[:notice] = 'You have updated movie successfully.'
      redirect_to genre_path(@genre.id)
    else
      render :edit
    end
  end

  def destroy
    @genre = Genre.find(params[:id])
    @genre.destroy
    redirect_to user_path(@genre.user_id)
  end

  private
  def genre_params
    params.require(:genre).permit(:title, :body)
  end

end
