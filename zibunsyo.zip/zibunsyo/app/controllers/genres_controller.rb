class GenresController < ApplicationController

  def create
    @genre = Genre.new(genre_params)
    @genre.user_id = current_user.id
    @genre.save
    redirect_to genre_path(@genre.id)
  end

  def show
  end

  def edit
  end

  private
  def genre_params
    params.require(:genre).permit(:title, :body)
  end

end
